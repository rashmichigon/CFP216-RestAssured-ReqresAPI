package com.selenium.apitest;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;

import java.sql.SQLException;

import static io.restassured.RestAssured.given;

public class ReqresAPI {
    @Test
    public void GetListUsersSuccess_ReturnsOK()
    {
        RestAssured.baseURI = "https://reqres.in/api/users?page=2";
        RequestSpecification httpRequest = RestAssured.given();
        Response response = httpRequest.request(Method.GET, "");
        System.out.println("Status received => " + response.getStatusLine());
        System.out.println("Response=>" + response.prettyPrint());
    }

    @Test
    public void PostUsersSuccess_ReturnsOK()
    {
        Response response = given().header("Content-Type","application/json")
                .header("accept","application/json")
                .body("{\n"+
                "\"name\":\"morpheus\",\n"+
                        "  \"job\": \"leader\",\n" +
                        "}")
                .when()
                .post("https://reqres.in/api/users");
        response.prettyPrint();
        response.then().assertThat().statusCode(200);
    }
    @Test
    public void DeleteUsersSuccess_ReturnsOK() throws SQLException
    {
        Response response = given().accept("application/json")
                .contentType("application/json")
                .when()
                .delete("https://reqres.in/api/users/2");
        response.prettyPrint();
        System.out.println(response.then().statusCode(204));
    }
    @Test
    public void LoginUserSuccess_ReturnOK()
    {
        Response response = given().header("accept","application/json")
                .queryParam("email","eve.holt@reqres.in")
                .queryParam("password","cityslicka")
                .when()
                .get("https://reqres.in/api/login?email&password");
        response.prettyPrint();
        response.then().assertThat().statusCode(200);
    }

}


